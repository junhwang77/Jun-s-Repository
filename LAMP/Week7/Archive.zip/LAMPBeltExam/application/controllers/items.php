<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Items extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->output->enable_profiler();
	}
    public function dashboard()
    {
        $logged_in = $this->session->userdata('logged_in');
        $id = $logged_in['id'];
        $wishlist = $this->Item->all_items_users_id($id);
        var_dump($wishlist);
        $this->load->view('dashboard', array(
                                             'logged_in' => $logged_in,
                                             'wishlist' => $wishlist));
    }
    public function wish_list_join($id)
    {
        $logged_in = $this->session->userdata('logged_in');
        $join = array('users_id' => $logged_in['user_id'],
                      'items_id' => $id);
        $item = $this->Item->get_item_by_id($id);
        $this->Item->remove_user($item['users_id'], $id);
        $this->Item->add_item_to_wl($join);
        redirect('/dashboard');
    }
    public function add_item()
    {
        $this->load->view('create');
    }
    public function create_item()
    {
        $item = $this->input->post('item');
        $added_by = $this->session->userdata('logged_in');
        $item = array('item' => $item,
                      'added_by' => $added_by['username']);
        $this->Item->add_item($item);
        $query = $this->Item->get_items_by_name($item['item']);
        $join = array('users_id' => $added_by['user_id'],
                      'items_id' => $query['id']);
        $this->Item->add_item_to_wl($join);
        redirect('/dashboard');
    }
    public function remove_wish($id)
    {
        $item = $this->Item->get_item_by_id($id);
        $user = $this->User->get_user_by_username($item['added_by']);
        $items = array('users_id' => $user['id'],
                       'items_id' => $id);
        $this->Item->add_wish($items);
        redirect('/dashboard');
    }
    public function show_item($id)
    {
        $item = $this->Item->get_item_by_id($id);
        var_dump($item);
    }
}
?>
