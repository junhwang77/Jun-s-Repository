<?php
class Item extends CI_Model {
    function get_all_items()
    {
        return $this->db->query("SELECT * FROM items")->result_array();
    }
    function get_item_by_id($id)
    {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->join('users_has_items', 'users_has_items.users_id=users.id');
        $this->db->join('items', 'users_has_items.items_id = items.id');
        $this->db->where('items_id', $id);
        return $this->db->get()->row_array();
    }
    // function get_user_by_email($email)
    // {
    //     return $this->db->query("SELECT * FROM users WHERE email = ?", array($email))->row_array();
    // }
    function get_items_by_name($item)
    {
        return $this->db->query("SELECT * FROM items WHERE item = ?", array($item))->row_array();
    }
    function add_item($item)
    {
        $query = "INSERT INTO items (item, added_by, created_at, updated_at) VALUES(?,?,?,?)";
        $values = array($item['item'], $item['added_by'], date("Y-m-d, H:i:s"), date("Y-m-d, H:i:s"));
        return $this->db->query($query, $values);
    }
    function add_item_to_wl($join)
    {
        $query = "INSERT INTO users_has_items (users_id, items_id) VALUES(?,?)";
        $values = array($join['users_id'], $join['items_id']);
        return $this->db->query($query, $values);
    }
    function join_items_users()
    {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->join('users_has_items', 'users_has_items.users_id=users.id');
        $this->db->join('items', 'users_has_items.items_id = items.id');
        return $this->db->get()->result_array();
    }
    function all_items_users_id($id)
    {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->join('users_has_items', 'users_has_items.users_id=users.id');
        $this->db->join('items', 'users_has_items.items_id = items.id');
        $this->db->where('user_id', $id);
        return $this->db->get()->result_array();
    }
    function add_wish($item)
    {
        $query = "UPDATE users_has_items SET users_id = ? WHERE items_id = ?";
        $set = array($item['users_id'], $item['items_id']);
        return $this->db->query($query, $set);
    }
    function remove_user($uid, $iid)
    {
        $query = "DELETE FROM users_has_items WHERE users_id = ? AND items_id = ?";
        $where = array($uid, $iid);
        return $this->db->query($query, $where);
    }
}

 ?>
