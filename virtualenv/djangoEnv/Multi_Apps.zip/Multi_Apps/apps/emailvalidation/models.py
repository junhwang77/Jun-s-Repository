from __future__ import unicode_literals

from django.db import models
import re

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')

# Create your models here.
class EmailManager(models.Manager):
    def register(self, email):
        errors = []
        if len(email) < 1:
            errors.append("The field cannot be blank")
        elif not EMAIL_REGEX.match(email):
            errors.append("Invalid email address")
        if len(errors) is not 0:
            return (False, errors)
        else:
            e = Email.emailmanager.create(email=email)
            e.save()
            return (True, e)

    def destroy(self, id):
        e = Email.emailmanager.get(id=id)
        if not e:
            return (False, "Email ID not found")
        else:
            e.delete()
            return (True, "Email Deleted")

class Email(models.Model):
    email = models.CharField(max_length=100)
    created_at = models.DateField(auto_now_add=True)
    updated_at = models.DateField(auto_now=True)
    emailmanager = EmailManager()
