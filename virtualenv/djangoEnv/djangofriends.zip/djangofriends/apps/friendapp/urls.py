from django.conf.urls import url
from . import views
urlpatterns = [
    url(r'^$', views.index, name = 'index'),
    url(r'^one$', views.one),
    url(r'^two$', views.two),
    url(r'^three$', views.three),
    url(r'^four$', views.four),
    url(r'^five$', views.five),
    url(r'^six$', views.six),
    url(r'^seven$', views.seven),
    url(r'^eight$', views.eight),
    url(r'^nine$', views.nine),
    url(r'^ten$', views.ten),
    url(r'^eleven$', views.eleven),
    url(r'^twelve$', views.twelve),
    url(r'^thirteen$', views.thirteen),
    url(r'^fourteen$', views.fourteen),
]
