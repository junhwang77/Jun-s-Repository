from django.shortcuts import render, redirect
from . import models
# Create your views here.
def index(req):
    users = models.Users.objects.all()
    print users.query
    print users
    context = {
        'users':users
    }
    return render(req, "friendapp/index.html", context)

def one(req):
    users = models.Users.objects.filter(last_name='Rodriguez')
    context = {
        'users':users
    }
    return render(req, "friendapp/index.html", context)

def two(req):
    users = models.Users.objects.exclude(last_name='Rodriguez')
    context = {
        'users':users
    }
    return render(req, "friendapp/index.html", context)

def three(req):
    users = models.Users.objects.filter(last_name='Rodriguez')|models.Users.objects.filter(first_name='Daniel')
    context = {
        'users':users
    }
    return render(req, "friendapp/index.html", context)

def four(req):
    users = models.Users.objects.filter(last_name='Rodriguez').exclude(first_name='Madison')
    context = {
        'users':users
    }
    return render(req, "friendapp/index.html", context)

def five(req):
    users = models.Users.objects.exclude(first_name='Daniel').exclude(first_name='Michael')
    context = {
        'users':users
    }
    return render(req, "friendapp/index.html", context)

def six(req):
    users = models.Users.objects.get(id=1)
    context = {
        'first_name':users.first_name,
        'last_name':users.last_name
    }
    return render(req, "friendapp/index.html", context)

def seven(req):
    users = models.Users.objects.get(last_name='Rodriguez')
    print users
    context = {
        'first_name':users.first_name,
        'last_name':users.last_name
    }
    return render(req, "friendapp/index.html", context)

def eight(req):
    users = models.Users.objects.get(id=10000)
    print users
    context = {
        'first_name':users.first_name,
        'last_name':users.last_name
    }
    return render(req, "friendapp/index.html", context)

def nine(req):
    users = models.Users.objects.order_by('first_name')
    print users
    context = {
        'users':users
    }
    return render(req, "friendapp/index.html", context)

def ten(req):
    users = models.Users.objects.order_by('-last_name')
    print users
    context = {
        'users':users
    }
    return render(req, "friendapp/index.html", context)

def eleven(req):
    users = models.Friendships.objects.all()
    print users.query
    print users
    context = {
        'users':users
    }
    return render(req, "friendapp/index.html", context)

def twelve(req):
    users = models.Users.objects.filter(id=4)
    print users.query
    print users
    context = {
        'users':users
    }
    return render(req, "friendapp/index.html", context)

def thirteen(req):
    users = models.Users.objects.filter(id=4)
    friendships = models.Friendships.objects.filter(user=4)
    print friendships.query
    print friendships
    context = {
        'users':users,
        'friendships':friendships
    }
    return render(req, "friendapp/index.html", context)

def fourteen(req):
    users = models.Users.objects.exclude(id=4).exclude(id=5).exclude(id=6)
    friendships = models.Friendships.objects.exclude(user=4).exclude(user=5).exclude(user=6)
    print friendships.query
    print friendships
    context = {
        'users':users,
        'friendships':friendships
    }
    return render(req, "friendapp/index.html", context)
