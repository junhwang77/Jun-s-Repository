from django.shortcuts import render
from django.db.models import Count
from . import models
# Create your views here.
def index(req):
    cities = models.Countries.objects.filter(languagetocountry__language='slovene')
    languages = models.Languages.objects.filter(language='slovene')
    # prints the queries
    print (50*"*")
    print cities.query
    print (50*"*")
    print languages.query
    print (50*"*")
    return render(req, 'worldApp/index.html', context={'cities':cities})

def one(req):
    countries = models.Countries.objects.filter(languagetocountry__language='slovene').order_by('-languagetocountry__percentage')
    languages = models.Languages.objects.filter(language = 'slovene')
    context = {
        'countries':countries,
        'languages':languages,
    }
    return render(req, 'worldApp/index.html', context)

def two(req):
    countries = models.Countries.objects.annotate(num_cities=Count('citytocountry')).order_by('-num_cities')
    context = {
        'countries':countries,
    }
    return render(req, 'worldApp/index.html', context)

def three(req):
    countries = models.Countries.objects.filter(name="Mexico")
    cities = models.Cities.objects.filter(population__gt=500000).order_by('-population')
    context = {
        'countries':countries,
        'cities':cities,
    }
    return render(req, 'worldApp/index.html', context)

def four(req):
    countries = models.Countries.objects.filter(languagetocountry__percentage__gt=89).order_by('-languagetocountry__percentage')
    languages = models.Languages.objects.filter(percentage__gt=89)
    context = {
        'countries':countries,
        'languages':languages,
    }
    return render(req, 'worldApp/index.html', context)

def five(req):
    countries = models.Countries.objects.filter(surface_area__lt=501).filter(population__gt=100000)
    context = {
        'countries':countries,
    }
    return render(req, 'worldApp/index.html', context)

def six(req):
    countries = models.Countries.objects.filter(government_form='Constitutional Monarchy').filter(capital__gt=200).filter(life_expectancy__gt=75)
    context = {
        'countries':countries,
    }
    return render(req, 'worldApp/index.html', context)

def seven(req):
    countries = models.Countries.objects.filter(name='Argentina')
    cities = models.Cities.objects.filter(district='Buenos Aires').filter(population__gt=500000)
    context = {
        'countries':countries,
        'cities':cities
    }
    return render(req, 'worldApp/index.html', context)

def eight(req):
    countries1 = models.Countries.objects.values('region').annotate(num_countries=Count('region')).order_by('-num_countries')

    context = {
        'countries1':countries1,
    }
    return render(req, 'worldApp/index.html', context)
