$(document).ready(function(){
    $('#textbox').scrollTop($('#textbox')[0].scrollHeight);
});
