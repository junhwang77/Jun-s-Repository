alert('Are you a ninja?');
