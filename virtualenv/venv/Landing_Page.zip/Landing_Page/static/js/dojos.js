alert('Do you want to be a ninja?');
